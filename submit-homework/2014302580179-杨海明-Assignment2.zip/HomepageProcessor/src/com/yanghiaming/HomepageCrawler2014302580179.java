package com.yanghiaming;

import java.io.File;

public class HomepageCrawler2014302580179 {
	
	private HomepageCrawler2014302580179(){};
	//单例模式
	private static HomepageCrawler2014302580179 singleton = null;
	public static HomepageCrawler2014302580179 getInstance() {
		if (singleton == null) {
			singleton = new HomepageCrawler2014302580179();
		}
		
		return singleton;
	}
	public void homepageCrawler() throws Exception  {
	    //抓取教师主页的URL		 
		String url = "http://staff.whu.edu.cn/show.jsp?lang=cn&n=Zha%20Quan%20Xing";
	        
		//调用HttpRequest类内的get方法   
		HttpRequest2014302580179 response = HttpRequest2014302580179.get(url);
		    
		String formName = "input.html";
	        
		//保存抓取文件	    
	    response.receive(new File(formName));

	}
}
