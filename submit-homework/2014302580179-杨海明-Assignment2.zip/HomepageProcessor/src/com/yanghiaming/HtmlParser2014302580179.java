package com.yanghiaming;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class HtmlParser2014302580179 {
	
	private static ArrayList<String> introduction = new ArrayList<>();
	private HtmlParser2014302580179() {}
	//单例模式
	private static HtmlParser2014302580179 singleton = null;
	public static HtmlParser2014302580179 grtInstance() {
		if (singleton == null) {
			singleton = new HtmlParser2014302580179();
		}
		return singleton;
	}
	public void htmlParser() throws Exception{
		//	加载document
		File inputHtml = new File("./input.html");
		Document doc = Jsoup.parse(inputHtml,"UTF-8");
		//抓取h3.title 和 <p></p>的内容
		Elements nameElements = doc.select("h3.title");
		Elements briefIntroductionElement = doc.select("p");
		//存入遍历器
		Iterator<Element> briefIntroductionIte =briefIntroductionElement.iterator();
		//储存老师姓名
		String name = nameElements.text();
		//将余下内容存入arraylist
		while (briefIntroductionIte.hasNext()) {
			
			introduction.add(briefIntroductionIte.next().text());
			
		}
		//创建新文件，开启输出流
		FileOutputStream  fs = new FileOutputStream(new File("./Output.txt"));
		PrintStream p = new PrintStream(fs);
		//写入教师姓名
		p.println(name);
		//写入其他信息
		for(int i = 0;i<introduction.size();i++){
			
			if (i == 0) {
				Pattern educationPattern = Pattern.compile("本科|硕士|博士");
				Matcher matcher3 = educationPattern.matcher(introduction.get(i));
				if (matcher3.find()) {
					p.print("学位： ");
					p.println(matcher3.group());
				}
				Pattern workPattern = Pattern.compile("教授|副教授|讲师");
				Matcher matcher4 = workPattern.matcher(introduction.get(i));
				if (matcher4.find()) {
					p.print("职位： ");
					p.println(matcher4.group());
				}
				Pattern telPattern = Pattern.compile("\\d{3}-\\d{8}");
				Matcher matcher1 = telPattern.matcher(introduction.get(i));
				if (matcher1.find()) {
					p.print("联系电话： ");
					p.println(matcher1.group());
				}
				Pattern mailPattern = Pattern.compile("\\w{5}@whu.edu.cn");
				Matcher matcher2 = mailPattern.matcher(introduction.get(i));
				if (matcher2.find()) {
					p.print("Email： ");
					p.println(matcher2.group());
				}
				
			}
			
			if (i == 3) {
				p.println("教育与研究经历：");
				p.println(introduction.get(i));
			}
			if (i == 6) {
				p.println("研究方向：");
				p.println(introduction.get(i));
			}
			if (i == 9) {
				p.println("学术兼职：");
				p.println(introduction.get(i));
			}
		}
		p.close();
	}		
}
