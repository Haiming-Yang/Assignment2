package com.yanghiaming;

public class Main2014302580179 {
	public static void main(String[] args) throws Exception {
   HomepageCrawler2014302580179.getInstance().homepageCrawler();
   HtmlParser2014302580179.grtInstance().htmlParser();
   

}
}